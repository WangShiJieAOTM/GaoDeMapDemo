package util;

/**
 * 包名： com.amap.navi.demo.util
 * <p>
 * 创建时间：2017/12/1
 * 项目名称：NaviDemo
 *
 * @author guibao.ggb
 * @email guibao.ggb@alibaba-inc.com
 * <p>
 * 类说明：
 */
public class ALiTTS {
}
