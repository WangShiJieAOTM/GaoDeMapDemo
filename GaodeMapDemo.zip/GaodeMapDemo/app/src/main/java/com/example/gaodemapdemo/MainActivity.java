package com.example.gaodemapdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.amap.api.location.AMapLocationClient;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AMapLocationClient.updatePrivacyShow(this, true, true);
        AMapLocationClient.updatePrivacyAgree(this, true);
    }

    public void jumpNaviActivity(View view) {
        startActivity(new Intent(this, NaviActivity.class));
    }

    public void jumpSearchActivity(View view) {
        startActivity(new Intent(this, SearchActivity.class));
    }
}